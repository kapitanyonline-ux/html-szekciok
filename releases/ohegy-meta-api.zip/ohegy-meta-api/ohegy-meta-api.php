<?php
/**
 * Plugin Name: ÓHEGY Meta API
 * Plugin URI:  https://onlinekapitany.hu
 * Description: Közvetlen post meta frissítés REST endpoint-on át (bypass Alfred duplicate flow). Endpoint: POST /wp-json/ohegy/v1/termek-meta
 * Version:     1.0.7
 * Author:      Online Captain Systems Kft.
 * Author URI:  https://onlinekapitany.hu
 * Text Domain: ohegy-meta-api
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'rest_api_init', 'ohegy_meta_api_register_routes' );
function ohegy_meta_api_register_routes() {
    register_rest_route( 'ohegy/v1', '/termek-meta', [
        'methods'             => 'POST',
        'callback'            => 'ohegy_meta_api_set',
        'permission_callback' => 'ohegy_meta_api_auth',
        'args'                => [
            'post_id'    => [ 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ],
            'meta_key'   => [ 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_key' ],
            'meta_value' => [ 'required' => true ],
        ],
    ] );

    // POST: set page template + post meta bypass
    register_rest_route( 'ohegy/v1', '/page-meta', [
        'methods'             => 'POST',
        'callback'            => 'ohegy_meta_api_page_meta',
        'permission_callback' => 'ohegy_meta_api_auth',
        'args'                => [
            'post_id'    => [ 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ],
            'meta_key'   => [ 'required' => true, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ],
            'meta_value' => [ 'required' => true ],
        ],
    ] );

    // POST: set WP options (allowlisted)
    register_rest_route( 'ohegy/v1', '/set-option', [
        'methods'             => 'POST',
        'callback'            => 'ohegy_meta_api_set_option',
        'permission_callback' => 'ohegy_meta_api_auth',
        'args'                => [
            'option_name'  => [ 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_key' ],
            'option_value' => [ 'required' => true ],
        ],
    ] );

    // POST: switch active WP theme (allowlisted slugs only)
    register_rest_route( 'ohegy/v1', '/switch-theme', [
        'methods'             => 'POST',
        'callback'            => 'ohegy_meta_api_switch_theme',
        'permission_callback' => 'ohegy_meta_api_auth',
        'args'                => [
            'theme' => [ 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
        ],
    ] );

    // POST: direct wp_update_post content bypass (for published pages Alfred duplicates)
    register_rest_route( 'ohegy/v1', '/post-content', [
        'methods'             => 'POST',
        'callback'            => 'ohegy_meta_api_set_content',
        'permission_callback' => 'ohegy_meta_api_auth',
        'args'                => [
            'post_id' => [ 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ],
            'content' => [ 'required' => true, 'type' => 'string' ],
        ],
    ] );

    // POST: flush WP rewrite rules (needed after CPT registration changes)
    register_rest_route( 'ohegy/v1', '/flush-rewrites', [
        'methods'             => 'POST',
        'callback'            => function() {
            flush_rewrite_rules( false );
            return [ 'success' => true, 'message' => 'Rewrite rules flushed.' ];
        },
        'permission_callback' => 'ohegy_meta_api_auth',
    ] );

    // POST: set featured image (_thumbnail_id) on ohegy_kategoria or ohegy_termek
    register_rest_route( 'ohegy/v1', '/set-featured-image', [
        'methods'             => 'POST',
        'callback'            => 'ohegy_meta_api_set_featured_image',
        'permission_callback' => 'ohegy_meta_api_auth',
        'args'                => [
            'post_id'  => [ 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ],
            'image_id' => [ 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ],
        ],
    ] );

    // GET endpoint for reading meta (useful for verification)
    register_rest_route( 'ohegy/v1', '/termek-meta', [
        'methods'             => 'GET',
        'callback'            => 'ohegy_meta_api_get',
        'permission_callback' => 'ohegy_meta_api_auth',
        'args'                => [
            'post_id'  => [ 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ],
            'meta_key' => [ 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_key', 'default' => '_ohegy_kategoria_id' ],
        ],
    ] );
}

/**
 * Auth: accept the Alfred API key (validated via Alfred's own endpoint)
 * or any logged-in user with edit_posts capability.
 */
function ohegy_meta_api_auth() {
    if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
        return true;
    }

    $incoming = sanitize_text_field( $_SERVER['HTTP_X_ALFRED_KEY'] ?? '' );
    if ( empty( $incoming ) ) {
        return false;
    }

    // Delegate to Alfred's validate-key endpoint (avoids needing to know storage format)
    $response = wp_remote_post( home_url( '/wp-json/alfred/v1/auth/validate-key' ), [
        'headers' => [
            'Content-Type' => 'application/json',
            'X-Alfred-Key'  => $incoming,
        ],
        'body'    => wp_json_encode( [ 'key' => $incoming ] ),
        'timeout' => 5,
    ] );

    if ( is_wp_error( $response ) ) {
        return false;
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    return ! empty( $body['valid'] );
}

function ohegy_meta_api_set( WP_REST_Request $request ) {
    $post_id    = $request->get_param( 'post_id' );
    $meta_key   = $request->get_param( 'meta_key' );
    $meta_value = $request->get_param( 'meta_value' );

    // Allowlist: only ohegy_termek meta keys
    $allowed = [ '_ohegy_kategoria_id' ];
    if ( ! in_array( $meta_key, $allowed, true ) ) {
        return new WP_Error( 'forbidden_key', 'Meta key not allowed.', [ 'status' => 403 ] );
    }

    $post = get_post( $post_id );
    if ( ! $post || $post->post_type !== 'ohegy_termek' ) {
        return new WP_Error( 'not_found', 'ohegy_termek nem található.', [ 'status' => 404 ] );
    }

    update_post_meta( $post_id, $meta_key, absint( $meta_value ) );
    $saved = (int) get_post_meta( $post_id, $meta_key, true );

    return [
        'success'    => true,
        'post_id'    => $post_id,
        'post_title' => $post->post_title,
        'meta_key'   => $meta_key,
        'meta_value' => $saved,
    ];
}

function ohegy_meta_api_page_meta( WP_REST_Request $request ) {
    $post_id    = $request->get_param( 'post_id' );
    $meta_key   = $request->get_param( 'meta_key' );
    $meta_value = $request->get_param( 'meta_value' );

    $allowed_keys = [ '_wp_page_template', '_ohegy_kategoria_id' ];
    if ( ! in_array( $meta_key, $allowed_keys, true ) ) {
        return new WP_Error( 'forbidden_key', 'Meta key not allowed.', [ 'status' => 403 ] );
    }

    $post = get_post( $post_id );
    if ( ! $post ) {
        return new WP_Error( 'not_found', 'Post not found.', [ 'status' => 404 ] );
    }

    update_post_meta( $post_id, $meta_key, sanitize_text_field( $meta_value ) );

    return [
        'success'    => true,
        'post_id'    => $post_id,
        'post_title' => $post->post_title,
        'meta_key'   => $meta_key,
        'meta_value' => get_post_meta( $post_id, $meta_key, true ),
    ];
}

function ohegy_meta_api_set_option( WP_REST_Request $request ) {
    $name  = $request->get_param( 'option_name' );
    $value = $request->get_param( 'option_value' );

    $allowed = [ 'show_on_front', 'page_on_front', 'page_for_posts', 'blogname', 'blogdescription' ];
    if ( ! in_array( $name, $allowed, true ) ) {
        return new WP_Error( 'forbidden_option', 'Option not allowed.', [ 'status' => 403 ] );
    }

    update_option( $name, sanitize_text_field( $value ) );

    return [
        'success'      => true,
        'option_name'  => $name,
        'option_value' => get_option( $name ),
    ];
}

function ohegy_meta_api_set_content( WP_REST_Request $request ) {
    $post_id = $request->get_param( 'post_id' );
    $content = $request->get_param( 'content' );

    $post = get_post( $post_id );
    if ( ! $post ) {
        return new WP_Error( 'not_found', 'Post not found.', [ 'status' => 404 ] );
    }

    $result = wp_update_post( [
        'ID'           => $post_id,
        'post_content' => $content,
    ], true );

    if ( is_wp_error( $result ) ) {
        return new WP_Error( 'update_failed', $result->get_error_message(), [ 'status' => 500 ] );
    }

    return [
        'success'        => true,
        'post_id'        => $post_id,
        'content_length' => strlen( $content ),
    ];
}

function ohegy_meta_api_switch_theme( WP_REST_Request $request ) {
    $slug = $request->get_param( 'theme' );

    $allowed_themes = [ 'captain-base', 'hello-elementor' ];
    if ( ! in_array( $slug, $allowed_themes, true ) ) {
        return new WP_Error( 'forbidden_theme', 'Theme slug not on allowlist.', [ 'status' => 403 ] );
    }

    $theme = wp_get_theme( $slug );
    if ( ! $theme->exists() ) {
        return new WP_Error( 'theme_not_found', "Theme '{$slug}' not found on server.", [ 'status' => 404 ] );
    }

    switch_theme( $slug );

    return [
        'success'    => true,
        'active'     => get_option( 'stylesheet' ),
        'stylesheet' => get_option( 'stylesheet' ),
        'template'   => get_option( 'template' ),
    ];
}

function ohegy_meta_api_set_featured_image( WP_REST_Request $request ) {
    $post_id  = $request->get_param( 'post_id' );
    $image_id = $request->get_param( 'image_id' );

    $post = get_post( $post_id );
    if ( ! $post ) {
        return new WP_Error( 'not_found', 'Post not found.', [ 'status' => 404 ] );
    }

    $allowed_types = [ 'ohegy_kategoria', 'ohegy_termek' ];
    if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
        return new WP_Error( 'forbidden_type', 'Post type not allowed.', [ 'status' => 403 ] );
    }

    if ( ! wp_attachment_is_image( $image_id ) ) {
        return new WP_Error( 'invalid_image', 'Image ID does not point to a valid attachment.', [ 'status' => 400 ] );
    }

    update_post_meta( $post_id, '_thumbnail_id', $image_id );
    $saved = (int) get_post_meta( $post_id, '_thumbnail_id', true );

    return [
        'success'    => true,
        'post_id'    => $post_id,
        'post_title' => $post->post_title,
        'image_id'   => $saved,
        'image_url'  => wp_get_attachment_image_url( $saved, 'medium' ),
    ];
}

function ohegy_meta_api_get( WP_REST_Request $request ) {
    $post_id  = $request->get_param( 'post_id' );
    $meta_key = $request->get_param( 'meta_key' );

    $post = get_post( $post_id );
    if ( ! $post || $post->post_type !== 'ohegy_termek' ) {
        return new WP_Error( 'not_found', 'ohegy_termek nem található.', [ 'status' => 404 ] );
    }

    return [
        'post_id'    => $post_id,
        'post_title' => $post->post_title,
        'meta_key'   => $meta_key,
        'meta_value' => (int) get_post_meta( $post_id, $meta_key, true ),
    ];
}
