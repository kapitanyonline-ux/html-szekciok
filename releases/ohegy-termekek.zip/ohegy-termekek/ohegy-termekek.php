<?php
/**
 * Plugin Name: ÓHEGY Termékek
 * Plugin URI:  https://onlinekapitany.hu
 * Description: Egyedi termék- és kategória posztok az ÓHEGY Plast Kft. katalógusához. Shortcode-ok: [ohegy_kategoriak] és [ohegy_termekek kategoria="slug-vagy-id"].
 * Version:     1.0.6
 * Author:      Online Captain Systems Kft.
 * Author URI:  https://onlinekapitany.hu
 * Text Domain: ohegy-termekek
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── CPT regisztrálás ──────────────────────────────────────────────────────

add_action( 'init', 'ohegy_register_cpts' );
function ohegy_register_cpts() {

    // 1) Kategória CPT
    register_post_type( 'ohegy_kategoria', [
        'label'               => 'Kategóriák',
        'labels'              => [
            'name'               => 'Kategóriák',
            'singular_name'      => 'Kategória',
            'add_new'            => 'Új kategória',
            'add_new_item'       => 'Új kategória hozzáadása',
            'edit_item'          => 'Kategória szerkesztése',
            'new_item'           => 'Új kategória',
            'view_item'          => 'Kategória megtekintése',
            'search_items'       => 'Kategóriák keresése',
            'not_found'          => 'Nincs kategória.',
            'not_found_in_trash' => 'Nincs kategória a kukában.',
            'menu_name'          => 'Kategóriák',
            'all_items'          => 'Összes kategória',
        ],
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => 'ohegy-termekek',
        'show_in_rest'        => true,
        'supports'            => [ 'title', 'excerpt', 'thumbnail' ],
        'has_archive'         => false,
        'rewrite'             => [ 'slug' => 'ohegy-kategoriak' ],
        'menu_position'       => 22,
    ] );

    // 2) Termék CPT
    register_post_type( 'ohegy_termek', [
        'label'               => 'Termékek',
        'labels'              => [
            'name'               => 'Termékek',
            'singular_name'      => 'Termék',
            'add_new'            => 'Új termék',
            'add_new_item'       => 'Új termék hozzáadása',
            'edit_item'          => 'Termék szerkesztése',
            'new_item'           => 'Új termék',
            'view_item'          => 'Termék megtekintése',
            'search_items'       => 'Termékek keresése',
            'not_found'          => 'Nincs termék.',
            'not_found_in_trash' => 'Nincs termék a kukában.',
            'menu_name'          => 'Termékek',
            'all_items'          => 'Összes termék',
        ],
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => 'ohegy-termekek',
        'show_in_rest'        => true,
        'supports'            => [ 'title', 'excerpt', 'thumbnail' ],
        'has_archive'         => false,
        'rewrite'             => [ 'slug' => 'ohegy-termekek' ],
    ] );
}

// ── Admin főmenü ──────────────────────────────────────────────────────────

add_action( 'admin_menu', 'ohegy_admin_menu' );
function ohegy_admin_menu() {
    add_menu_page(
        'ÓHEGY Termékek',
        'ÓHEGY Termékek',
        'edit_posts',
        'ohegy-termekek',
        'ohegy_admin_page',
        'dashicons-archive',
        22
    );
    add_submenu_page( 'ohegy-termekek', 'Összes termék',   'Termékek',    'edit_posts', 'edit.php?post_type=ohegy_termek' );
    add_submenu_page( 'ohegy-termekek', 'Összes kategória','Kategóriák',  'edit_posts', 'edit.php?post_type=ohegy_kategoria' );
    add_submenu_page( 'ohegy-termekek', 'Új termék',       'Új termék',   'edit_posts', 'post-new.php?post_type=ohegy_termek' );
    add_submenu_page( 'ohegy-termekek', 'Új kategória',    'Új kategória','edit_posts', 'post-new.php?post_type=ohegy_kategoria' );
}

function ohegy_admin_page() {
    echo '<div class="wrap"><h1>ÓHEGY Termékek</h1>';
    echo '<p>Shortcode-ok: <code>[ohegy_kategoriak]</code> és <code>[ohegy_termekek kategoria="kategoria-slug-vagy-id"]</code></p>';
    echo '</div>';
}

// ── Meta box: termék → kategória kötés ───────────────────────────────────

add_action( 'add_meta_boxes', 'ohegy_add_metabox' );
function ohegy_add_metabox() {
    add_meta_box(
        'ohegy_kategoria_box',
        'Kategória',
        'ohegy_metabox_render',
        'ohegy_termek',
        'side',
        'high'
    );
}

function ohegy_metabox_render( $post ) {
    $current = (int) get_post_meta( $post->ID, '_ohegy_kategoria_id', true );
    wp_nonce_field( 'ohegy_save_meta', 'ohegy_meta_nonce' );

    $kategoriak = get_posts( [
        'post_type'      => 'ohegy_kategoria',
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
        'post_status'    => 'publish',
    ] );

    echo '<select name="ohegy_kategoria_id" style="width:100%;">';
    echo '<option value="">— Nincs kategória —</option>';
    foreach ( $kategoriak as $kat ) {
        $selected = selected( $current, $kat->ID, false );
        echo '<option value="' . esc_attr( $kat->ID ) . '"' . $selected . '>' . esc_html( $kat->post_title ) . '</option>';
    }
    echo '</select>';
    echo '<p style="margin-top:.5rem;font-size:11px;color:#646970;">A termék melyik kategóriához tartozik.</p>';
}

add_action( 'save_post_ohegy_termek', 'ohegy_save_meta' );
function ohegy_save_meta( $post_id ) {
    if (
        ! isset( $_POST['ohegy_meta_nonce'] ) ||
        ! wp_verify_nonce( $_POST['ohegy_meta_nonce'], 'ohegy_save_meta' ) ||
        defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ||
        ! current_user_can( 'edit_post', $post_id )
    ) {
        return;
    }
    $kat_id = isset( $_POST['ohegy_kategoria_id'] ) ? (int) $_POST['ohegy_kategoria_id'] : 0;
    if ( $kat_id > 0 ) {
        update_post_meta( $post_id, '_ohegy_kategoria_id', $kat_id );
    } else {
        delete_post_meta( $post_id, '_ohegy_kategoria_id' );
    }
}

// ── REST API: expose _ohegy_kategoria_id ─────────────────────────────────

add_action( 'rest_api_init', 'ohegy_register_rest_meta' );
function ohegy_register_rest_meta() {
    register_post_meta( 'ohegy_termek', '_ohegy_kategoria_id', [
        'show_in_rest'      => true,
        'single'            => true,
        'type'              => 'integer',
        'auth_callback'     => function() { return current_user_can( 'edit_posts' ); },
        'sanitize_callback' => 'absint',
    ] );
}

// ── Shortcode: [ohegy_kategoriak] ────────────────────────────────────────

add_shortcode( 'ohegy_kategoriak', 'ohegy_sc_kategoriak' );
function ohegy_sc_kategoriak( $atts ) {
    $atts = shortcode_atts( [
        'limit'   => -1,
        'eyebrow' => '',
        'title'   => '',
        'desc'    => '',
        'id'      => '',
        'layout'  => 'grid', // 'grid' | 'slider'
    ], $atts, 'ohegy_kategoriak' );

    // Slider mode: always fetch all categories regardless of limit
    $limit = ( 'slider' === $atts['layout'] ) ? -1 : (int) $atts['limit'];

    $posts = get_posts( [
        'post_type'      => 'ohegy_kategoria',
        'posts_per_page' => $limit,
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
        'post_status'    => 'publish',
    ] );

    if ( empty( $posts ) ) {
        return '<p style="color:#5B6573;">Még nincs közzétett kategória.</p>';
    }

    if ( 'slider' === $atts['layout'] ) {
        return ohegy_sc_kategoriak_slider( $atts, $posts );
    }

    $vars  = '--oh-red:#E2231A;--oh-red-2:#B71810;--oh-black:#1A1A1A;--oh-grey:#E2E6EC;--oh-grey-bg:#F3F5F8;--oh-text-mid:#5B6573;--oh-head:\'Archivo\',sans-serif;--oh-body:\'Inter\',sans-serif';
    $fonts = '<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">';

    $css = '
<style>
.ohegy-kategoriak-sec{box-sizing:border-box;font-family:var(--oh-body);color:var(--oh-black);line-height:1.5;padding:5rem 1.5rem;background:#fff;width:100%;overflow-x:hidden;}
.ohegy-kategoriak-sec *,.ohegy-kategoriak-sec *::before,.ohegy-kategoriak-sec *::after{box-sizing:border-box;}
.ohegy-kategoriak-sec__inner{max-width:1280px;margin:0 auto;width:100%;}
.ohegy-kategoriak-sec__eyebrow{font-family:var(--oh-head);font-weight:700;font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:var(--oh-red);margin-bottom:.85rem;}
.ohegy-kategoriak-sec__title{font-family:var(--oh-head);font-weight:900;font-size:clamp(1.8rem,4vw,2.8rem);color:var(--oh-black);line-height:1.1;text-transform:uppercase;margin-bottom:1rem;}
.ohegy-kategoriak-sec__desc{font-size:1rem;color:var(--oh-text-mid);max-width:640px;margin-bottom:2.5rem;line-height:1.65;}
.ohegy-kategoriak{font-family:var(--oh-body);color:var(--oh-black);line-height:1.5;width:100%;}
.ohegy-kategoriak *,.ohegy-kategoriak *::before,.ohegy-kategoriak *::after{box-sizing:border-box;margin:0;padding:0;}
.ohegy-kategoriak a{color:inherit;text-decoration:none !important;}
.ohegy-kategoriak__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.4rem;}
.ohegy-kategoriak__card{background:#fff;border:1px solid var(--oh-grey);border-radius:12px;overflow:hidden;transition:transform .2s,box-shadow .2s;min-width:0;}
.ohegy-kategoriak__card:hover{transform:translateY(-4px);box-shadow:0 18px 40px rgba(26,26,26,.12);}
.ohegy-kategoriak__img{height:180px;background:var(--oh-grey-bg);display:flex;align-items:center;justify-content:center;overflow:hidden;}
.ohegy-kategoriak__img img{width:100%;height:100%;object-fit:cover;}
.ohegy-kategoriak__img-ph{color:#b3bcc8;}
.ohegy-kategoriak__img-ph svg{width:58px;height:58px;}
.ohegy-kategoriak__body{padding:1.1rem 1.2rem;}
.ohegy-kategoriak__body h3{font-family:var(--oh-head);font-weight:800;font-size:1.05rem;color:var(--oh-black);margin-bottom:.35rem;line-height:1.15;text-transform:uppercase;}
.ohegy-kategoriak__body p{font-size:.84rem;color:var(--oh-text-mid);margin-bottom:.7rem;}
.ohegy-kategoriak__link{font-family:var(--oh-head) !important;font-weight:700 !important;font-size:.72rem;letter-spacing:.04em;text-transform:uppercase;color:var(--oh-black) !important;display:inline-flex;align-items:center;gap:.3rem;transition:color .2s;}
.ohegy-kategoriak__card:hover .ohegy-kategoriak__link{color:var(--oh-red) !important;}
.ohegy-kategoriak__link svg{width:14px;height:14px;}
@media(max-width:860px){.ohegy-kategoriak__grid{grid-template-columns:1fr 1fr;}.ohegy-kategoriak-sec{padding:3.5rem 1.25rem;}}
@media(max-width:540px){.ohegy-kategoriak__grid{grid-template-columns:1fr;}.ohegy-kategoriak-sec{padding:2.5rem 1rem;}}
</style>';

    $has_section = ! empty( $atts['title'] );
    $sec_id_attr = ( $has_section && $atts['id'] ) ? ' id="' . esc_attr( $atts['id'] ) . '"' : '';

    $html  = $fonts . $css;

    if ( $has_section ) {
        $html .= '<section class="ohegy-kategoriak-sec" style="' . esc_attr( $vars ) . '"' . $sec_id_attr . '>';
        $html .= '<div class="ohegy-kategoriak-sec__inner">';
        if ( $atts['eyebrow'] ) {
            $html .= '<p class="ohegy-kategoriak-sec__eyebrow">' . esc_html( $atts['eyebrow'] ) . '</p>';
        }
        $html .= '<h2 class="ohegy-kategoriak-sec__title">' . esc_html( $atts['title'] ) . '</h2>';
        if ( $atts['desc'] ) {
            $html .= '<p class="ohegy-kategoriak-sec__desc">' . esc_html( $atts['desc'] ) . '</p>';
        }
    }

    $html .= '<div class="ohegy-kategoriak"' . ( $has_section ? '' : ' style="' . esc_attr( $vars ) . '"' ) . '>';
    $html .= '<div class="ohegy-kategoriak__grid">';

    $arrow_svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>';

    foreach ( $posts as $p ) {
        $thumb   = get_the_post_thumbnail( $p->ID, 'medium', [ 'alt' => esc_attr( $p->post_title ) ] );
        $excerpt = $p->post_excerpt ? '<p>' . esc_html( $p->post_excerpt ) . '</p>' : '';
        $url     = get_permalink( $p->ID );

        $img_html = $thumb
            ? '<div class="ohegy-kategoriak__img">' . $thumb . '</div>'
            : '<div class="ohegy-kategoriak__img"><div class="ohegy-kategoriak__img-ph"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="m3 16 5-5 4 4 3-3 6 6"/><circle cx="8.5" cy="8.5" r="1.5"/></svg></div></div>';

        $html .= '<a class="ohegy-kategoriak__card" href="' . esc_url( $url ) . '">';
        $html .= $img_html;
        $html .= '<div class="ohegy-kategoriak__body">';
        $html .= '<h3>' . esc_html( $p->post_title ) . '</h3>';
        $html .= $excerpt;
        $html .= '<span class="ohegy-kategoriak__link">Termékek megtekintése ' . $arrow_svg . '</span>';
        $html .= '</div>';
        $html .= '</a>';
    }

    $html .= '</div></div>';

    if ( $has_section ) {
        $html .= '</div></section>';
    }

    return $html;
}

// ── Slider renderer (layout=slider ághoz) ────────────────────────────────

function ohegy_sc_kategoriak_slider( $atts, $posts ) {
    $vars        = '--oh-red:#E2231A;--oh-red-2:#B71810;--oh-black:#1A1A1A;--oh-grey:#E2E6EC;--oh-grey-bg:#F3F5F8;--oh-text-mid:#5B6573;--oh-head:\'Archivo\',sans-serif;--oh-body:\'Inter\',sans-serif';
    $fonts       = '<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">';
    $has_section = ! empty( $atts['title'] );
    $sec_id_attr = ( $has_section && $atts['id'] ) ? ' id="' . esc_attr( $atts['id'] ) . '"' : '';
    $count       = count( $posts );

    $css = '
<style>
/* === ÓHEGY Kategória Slider (ohegy-ks) === */
.ohegy-ks-sec{box-sizing:border-box;font-family:var(--oh-body);color:var(--oh-black);line-height:1.5;padding:5rem 1.5rem;background:#fff;width:100%;overflow-x:hidden;}
.ohegy-ks-sec *,.ohegy-ks-sec *::before,.ohegy-ks-sec *::after{box-sizing:border-box;}
.ohegy-ks-sec__inner{max-width:1280px;margin:0 auto;width:100%;}
.ohegy-ks-sec__eyebrow{font-family:var(--oh-head);font-weight:700;font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:var(--oh-red);margin-bottom:.85rem;}
.ohegy-ks-sec__title{font-family:var(--oh-head);font-weight:900;font-size:clamp(1.8rem,4vw,2.8rem);color:var(--oh-black);line-height:1.1;text-transform:uppercase;margin-bottom:1rem;}
.ohegy-ks-sec__desc{font-size:1rem;color:var(--oh-text-mid);max-width:640px;margin-bottom:2.5rem;line-height:1.65;}
/* Slider outer */
.ohegy-ks{position:relative;width:100%;padding:0 3rem;}
/* Nyilak */
.ohegy-ks__btn{position:absolute;top:50%;transform:translateY(-50%);z-index:10;width:44px;height:44px;border-radius:50%;border:2px solid var(--oh-grey);background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .18s,border-color .18s,box-shadow .18s;box-shadow:0 2px 8px rgba(26,26,26,.09);padding:0;}
.ohegy-ks__btn:hover:not(:disabled){background:var(--oh-red);border-color:var(--oh-red);color:#fff;box-shadow:0 4px 16px rgba(226,35,26,.25);}
.ohegy-ks__btn:disabled{opacity:.35;cursor:default;}
.ohegy-ks__btn--prev{left:0;}
.ohegy-ks__btn--next{right:0;}
.ohegy-ks__btn svg{width:20px;height:20px;stroke:currentColor;flex-shrink:0;}
/* Track */
.ohegy-ks__wrap{overflow:hidden;width:100%;}
.ohegy-ks__track{display:flex;gap:1.4rem;transition:transform .38s cubic-bezier(.25,.46,.45,.94);will-change:transform;align-items:stretch;}
/* Kártyák — méret JS-ből jön (flex-shrink:0 + JS width) */
.ohegy-ks__card{flex-shrink:0;min-width:0;background:#fff;border:1px solid var(--oh-grey);border-radius:12px;overflow:hidden;transition:box-shadow .2s;text-decoration:none !important;color:inherit;display:flex;flex-direction:column;}
.ohegy-ks__card:hover{box-shadow:0 18px 40px rgba(26,26,26,.12);}
.ohegy-ks__img{height:180px;background:var(--oh-grey-bg);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;}
.ohegy-ks__img img{width:100%;height:100%;object-fit:cover;}
.ohegy-ks__img-ph{color:#b3bcc8;}
.ohegy-ks__img-ph svg{width:58px;height:58px;}
.ohegy-ks__body{padding:1.1rem 1.2rem;flex:1;}
.ohegy-ks__body h3{font-family:var(--oh-head);font-weight:800;font-size:1.05rem;color:var(--oh-black);margin-bottom:.35rem;line-height:1.15;text-transform:uppercase;}
.ohegy-ks__body p{font-size:.84rem;color:var(--oh-text-mid);margin-bottom:.7rem;}
.ohegy-ks__link{font-family:var(--oh-head) !important;font-weight:700 !important;font-size:.72rem;letter-spacing:.04em;text-transform:uppercase;color:var(--oh-black) !important;display:inline-flex;align-items:center;gap:.3rem;transition:color .2s;}
.ohegy-ks__card:hover .ohegy-ks__link{color:var(--oh-red) !important;}
.ohegy-ks__link svg{width:14px;height:14px;}
/* Dots */
.ohegy-ks__dots{display:flex;justify-content:center;gap:.45rem;margin-top:1.6rem;}
.ohegy-ks__dot{width:8px;height:8px;border-radius:50%;background:var(--oh-grey);border:none;padding:0;cursor:pointer;transition:background .18s,transform .18s;}
.ohegy-ks__dot.is-active{background:var(--oh-red);transform:scale(1.3);}
/* Mobil */
@media(max-width:860px){
  .ohegy-ks{padding:0 2.5rem;}
  .ohegy-ks__btn{width:36px;height:36px;}
  .ohegy-ks__btn svg{width:16px;height:16px;}
  .ohegy-ks-sec{padding:3.5rem 1.25rem;}
}
@media(max-width:540px){
  .ohegy-ks{padding:0 2.2rem;}
  .ohegy-ks-sec{padding:2.5rem 1rem;}
}
</style>';

    $prev_svg = '<svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>';
    $next_svg = '<svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>';
    $arr_svg  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>';
    $ph_svg   = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="m3 16 5-5 4 4 3-3 6 6"/><circle cx="8.5" cy="8.5" r="1.5"/></svg>';

    $html  = $fonts . $css;
    $html .= '<section class="ohegy-ks-sec" style="' . esc_attr( $vars ) . '"' . $sec_id_attr . '>';
    $html .= '<div class="ohegy-ks-sec__inner">';

    if ( $has_section ) {
        if ( $atts['eyebrow'] ) {
            $html .= '<p class="ohegy-ks-sec__eyebrow">' . esc_html( $atts['eyebrow'] ) . '</p>';
        }
        $html .= '<h2 class="ohegy-ks-sec__title">' . esc_html( $atts['title'] ) . '</h2>';
        if ( $atts['desc'] ) {
            $html .= '<p class="ohegy-ks-sec__desc">' . esc_html( $atts['desc'] ) . '</p>';
        }
    }

    $html .= '<div class="ohegy-ks" data-count="' . esc_attr( $count ) . '">';
    $html .= '<button class="ohegy-ks__btn ohegy-ks__btn--prev" aria-label="Előző kategória" disabled>' . $prev_svg . '</button>';
    $html .= '<div class="ohegy-ks__wrap"><div class="ohegy-ks__track">';

    foreach ( $posts as $p ) {
        $thumb   = get_the_post_thumbnail( $p->ID, 'medium', [ 'alt' => esc_attr( $p->post_title ) ] );
        $excerpt = $p->post_excerpt ? '<p>' . esc_html( $p->post_excerpt ) . '</p>' : '';
        $url     = get_permalink( $p->ID );
        $img     = $thumb
            ? '<div class="ohegy-ks__img">' . $thumb . '</div>'
            : '<div class="ohegy-ks__img"><div class="ohegy-ks__img-ph">' . $ph_svg . '</div></div>';

        $html .= '<a class="ohegy-ks__card" href="' . esc_url( $url ) . '">';
        $html .= $img;
        $html .= '<div class="ohegy-ks__body">';
        $html .= '<h3>' . esc_html( $p->post_title ) . '</h3>';
        $html .= $excerpt;
        $html .= '<span class="ohegy-ks__link">Termékek megtekintése ' . $arr_svg . '</span>';
        $html .= '</div></a>';
    }

    $html .= '</div></div>'; // track + wrap
    $html .= '<button class="ohegy-ks__btn ohegy-ks__btn--next" aria-label="Következő kategória">' . $next_svg . '</button>';
    $html .= '</div>'; // ohegy-ks

    // Dot indicators
    $html .= '<div class="ohegy-ks__dots" aria-hidden="true">';
    for ( $i = 0; $i < $count; $i++ ) {
        $html .= '<button class="ohegy-ks__dot' . ( $i === 0 ? ' is-active' : '' ) . '" data-idx="' . $i . '"></button>';
    }
    $html .= '</div>';

    $html .= '</div></section>'; // inner + section

    // Vanilla JS carousel — no external dependencies
    $html .= '<script>(function(){
var GAP_REM=1.4;
document.querySelectorAll(".ohegy-ks").forEach(function(sl){
  var wrap=sl.querySelector(".ohegy-ks__wrap");
  var track=sl.querySelector(".ohegy-ks__track");
  var cards=sl.querySelectorAll(".ohegy-ks__card");
  var btnP=sl.querySelector(".ohegy-ks__btn--prev");
  var btnN=sl.querySelector(".ohegy-ks__btn--next");
  var dotsEl=sl.parentElement.querySelector(".ohegy-ks__dots");
  var dots=dotsEl?dotsEl.querySelectorAll(".ohegy-ks__dot"):[];
  var idx=0;
  var n=cards.length;
  if(!n)return;

  function vis(){return window.innerWidth<=540?1:window.innerWidth<=860?2:3;}
  function maxIdx(){return Math.max(0,n-vis());}
  function gap(){
    var g=parseFloat(getComputedStyle(track).columnGap||getComputedStyle(track).gap);
    return isNaN(g)?GAP_REM*16:g;
  }
  function setWidths(){
    var ww=wrap.offsetWidth;
    var v=vis();
    var g=gap();
    var cw=(ww-(v-1)*g)/v;
    cards.forEach(function(c){c.style.width=cw+"px";c.style.flexBasis=cw+"px";});
  }
  function step(){return cards[0]?(cards[0].offsetWidth+gap()):0;}
  function update(anim){
    if(!anim){track.style.transition="none";}
    track.style.transform="translateX(-"+(idx*step())+"px)";
    if(!anim){requestAnimationFrame(function(){track.style.transition="";});}
    btnP.disabled=idx<=0;
    btnN.disabled=idx>=maxIdx();
    dots.forEach(function(d,i){d.classList.toggle("is-active",i===idx);});
  }
  btnP.addEventListener("click",function(){idx=Math.max(0,idx-1);update(true);});
  btnN.addEventListener("click",function(){idx=Math.min(maxIdx(),idx+1);update(true);});
  dots.forEach(function(d,i){
    d.addEventListener("click",function(){
      idx=Math.min(i,maxIdx());update(true);
    });
  });
  /* Touch swipe */
  var tx=0;
  track.addEventListener("touchstart",function(e){tx=e.touches[0].clientX;},{passive:true});
  track.addEventListener("touchend",function(e){
    var dx=tx-e.changedTouches[0].clientX;
    if(Math.abs(dx)>44){idx=dx>0?Math.min(maxIdx(),idx+1):Math.max(0,idx-1);update(true);}
  },{passive:true});
  /* Resize */
  var rt;
  window.addEventListener("resize",function(){
    clearTimeout(rt);
    rt=setTimeout(function(){setWidths();idx=Math.min(idx,maxIdx());update(false);},120);
  });
  /* Init */
  setWidths();update(false);
});
})();</script>';

    return $html;
}

// ── Shortcode: [ohegy_termekek kategoria="slug-vagy-id"] ─────────────────

add_shortcode( 'ohegy_termekek', 'ohegy_sc_termekek' );
function ohegy_sc_termekek( $atts ) {
    $atts = shortcode_atts( [ 'kategoria' => '' ], $atts, 'ohegy_termekek' );
    $kat_param = sanitize_text_field( $atts['kategoria'] );

    if ( empty( $kat_param ) ) {
        return '<p style="color:#5B6573;">Megadatlan kategória.</p>';
    }

    // Kategória post azonosítása (ID vagy slug alapján)
    if ( is_numeric( $kat_param ) ) {
        $kat_id = (int) $kat_param;
    } else {
        $kat_post = get_page_by_path( $kat_param, OBJECT, 'ohegy_kategoria' );
        $kat_id   = $kat_post ? $kat_post->ID : 0;
    }

    if ( ! $kat_id ) {
        return '<p style="color:#5B6573;">Nem található kategória: ' . esc_html( $kat_param ) . '</p>';
    }

    $posts = get_posts( [
        'post_type'      => 'ohegy_termek',
        'posts_per_page' => -1,
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
        'post_status'    => 'publish',
        'meta_query'     => [
            [
                'key'   => '_ohegy_kategoria_id',
                'value' => $kat_id,
                'type'  => 'NUMERIC',
            ],
        ],
    ] );

    if ( empty( $posts ) ) {
        return '<p style="color:#5B6573;">Még nincsenek termékek ebben a kategóriában.</p>';
    }

    $vars = '--oh-red:#E2231A;--oh-red-2:#B71810;--oh-black:#1A1A1A;--oh-grey:#E2E6EC;--oh-grey-bg:#F3F5F8;--oh-text-mid:#5B6573;--oh-head:\'Archivo\',sans-serif;--oh-body:\'Inter\',sans-serif';

    $fonts = '<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">';

    $css = '
<style>
.ohegy-termekek{font-family:var(--oh-body);color:var(--oh-black);line-height:1.5;}
.ohegy-termekek *,.ohegy-termekek *::before,.ohegy-termekek *::after{box-sizing:border-box;margin:0;padding:0;}
.ohegy-termekek a{color:inherit;text-decoration:none !important;}
.ohegy-termekek__grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.4rem;}
.ohegy-termekek__card{background:#fff;border:1px solid var(--oh-grey);border-radius:12px;overflow:hidden;transition:transform .2s,box-shadow .2s;min-width:0;}
.ohegy-termekek__card:hover{transform:translateY(-4px);box-shadow:0 18px 40px rgba(26,26,26,.12);}
.ohegy-termekek__img{position:relative;height:180px;background:var(--oh-grey-bg);display:flex;align-items:center;justify-content:center;overflow:hidden;}
.ohegy-termekek__img img{width:100%;height:100%;object-fit:cover;}
.ohegy-termekek__img-ph{color:#b3bcc8;}
.ohegy-termekek__img-ph svg{width:58px;height:58px;}
.ohegy-termekek__body{padding:1.1rem 1.2rem;display:flex;flex-direction:column;gap:.35rem;}
.ohegy-termekek__body h3{font-family:var(--oh-head);font-weight:800;font-size:1rem;color:var(--oh-black);line-height:1.2;text-transform:uppercase;}
.ohegy-termekek__body p{font-size:.84rem;color:var(--oh-text-mid);}
.ohegy-termekek__link{font-family:var(--oh-head) !important;font-weight:700 !important;font-size:.72rem;letter-spacing:.04em;text-transform:uppercase;color:var(--oh-black) !important;display:inline-flex;align-items:center;gap:.3rem;transition:color .2s;margin-top:.35rem;}
.ohegy-termekek__card:hover .ohegy-termekek__link{color:var(--oh-red) !important;}
.ohegy-termekek__link svg{width:14px;height:14px;}
@media(max-width:860px){.ohegy-termekek__grid{grid-template-columns:1fr 1fr;}}
@media(max-width:540px){.ohegy-termekek__grid{grid-template-columns:1fr;}}
</style>';

    $arrow_svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>';

    $html = $fonts . $css;
    $html .= '<div class="ohegy-termekek" style="' . esc_attr( $vars ) . '">';
    $html .= '<div class="ohegy-termekek__grid">';

    foreach ( $posts as $p ) {
        $thumb   = get_the_post_thumbnail( $p->ID, 'medium', [ 'alt' => esc_attr( $p->post_title ) ] );
        $excerpt = $p->post_excerpt ? '<p>' . esc_html( $p->post_excerpt ) . '</p>' : '';
        $url     = get_permalink( $p->ID );

        $img_html = $thumb
            ? '<div class="ohegy-termekek__img">' . $thumb . '</div>'
            : '<div class="ohegy-termekek__img"><div class="ohegy-termekek__img-ph"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="m3 16 5-5 4 4 3-3 6 6"/><circle cx="8.5" cy="8.5" r="1.5"/></svg></div></div>';

        $html .= '<a class="ohegy-termekek__card" href="' . esc_url( $url ) . '">';
        $html .= $img_html;
        $html .= '<div class="ohegy-termekek__body">';
        $html .= '<h3>' . esc_html( $p->post_title ) . '</h3>';
        $html .= $excerpt;
        $html .= '<span class="ohegy-termekek__link">Részletek ' . $arrow_svg . '</span>';
        $html .= '</div>';
        $html .= '</a>';
    }

    $html .= '</div></div>';
    return $html;
}

// ── Single template override ──────────────────────────────────────────────

add_filter( 'template_include', 'ohegy_single_template' );
function ohegy_single_template( $template ) {
    if ( is_singular( 'ohegy_termek' ) || is_singular( 'ohegy_kategoria' ) ) {
        ob_start();
        ohegy_render_single( get_queried_object() );
        $content = ob_get_clean();
        file_put_contents( sys_get_temp_dir() . '/ohegy_single_' . get_queried_object_id() . '.html', $content );
        // Use index.php-based rendering via header/footer
        add_action( 'wp', function() use ( $content ) {
            status_header( 200 );
        } );
        add_filter( 'the_content', function( $c ) use ( $content ) { return $content; }, 99 );
        add_filter( 'wp_title', function() { return get_the_title() . ' – ÓHEGY Plast Kft.'; }, 99 );
        return locate_template( 'index.php' ) ?: $template;
    }
    return $template;
}

function ohegy_render_single( $post ) {
    $vars = '--oh-red:#E2231A;--oh-red-2:#B71810;--oh-black:#1A1A1A;--oh-grey:#E2E6EC;--oh-grey-bg:#F3F5F8;--oh-text-mid:#5B6573;--oh-head:\'Archivo\',sans-serif;--oh-body:\'Inter\',sans-serif';
    $fonts = '<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">';
    $is_termek   = $post->post_type === 'ohegy_termek';
    $is_kategoria = $post->post_type === 'ohegy_kategoria';

    // Breadcrumb
    $bc = '<div style="background:#F3F5F8;border-bottom:1px solid #E2E6EC;font-size:.8rem;color:#5B6573;padding:.7rem 0">';
    $bc .= '<div style="max-width:1200px;margin:0 auto;padding:0 clamp(1.2rem,4vw,2.5rem);display:flex;gap:.45rem;align-items:center;flex-wrap:wrap">';
    $bc .= '<a href="/" style="color:#5B6573;text-decoration:none">Főoldal</a>';
    $bc .= '<span style="color:#c2c9d2">/</span>';
    $bc .= '<a href="' . esc_url( get_permalink( 51 ) ) . '" style="color:#5B6573;text-decoration:none">Termékkatalógus</a>';

    if ( $is_termek ) {
        $kat_id = (int) get_post_meta( $post->ID, '_ohegy_kategoria_id', true );
        if ( $kat_id ) {
            $kat = get_post( $kat_id );
            if ( $kat ) {
                $bc .= '<span style="color:#c2c9d2">/</span>';
                $bc .= '<a href="' . esc_url( get_permalink( $kat_id ) ) . '" style="color:#5B6573;text-decoration:none">' . esc_html( $kat->post_title ) . '</a>';
            }
        }
        $bc .= '<span style="color:#c2c9d2">/</span>';
        $bc .= '<span style="color:#1A1A1A;font-weight:600">' . esc_html( $post->post_title ) . '</span>';
    } else {
        $bc .= '<span style="color:#c2c9d2">/</span>';
        $bc .= '<span style="color:#1A1A1A;font-weight:600">' . esc_html( $post->post_title ) . '</span>';
    }
    $bc .= '</div></div>';

    $thumb = get_the_post_thumbnail( $post->ID, 'large', [ 'style' => 'width:100%;height:360px;object-fit:cover;border-radius:12px;display:block;' ] );
    $excerpt = $post->post_excerpt;

    echo $fonts;
    echo '<div style="' . esc_attr( $vars ) . ';font-family:\'Inter\',sans-serif;color:#1A1A1A;line-height:1.5">';
    echo $bc;
    echo '<section style="padding:clamp(2.5rem,5vw,4rem) 0">';
    echo '<div style="max-width:1200px;margin:0 auto;padding:0 clamp(1.2rem,4vw,2.5rem)">';

    // Eyebrow
    $eyebrow = $is_kategoria ? 'Termékkategória' : 'Termék';
    echo '<p style="font-family:\'Archivo\',sans-serif;font-weight:700;font-size:.75rem;letter-spacing:.15em;text-transform:uppercase;color:#E2231A;margin:0 0 .5rem">' . esc_html( $eyebrow ) . '</p>';

    // Title
    echo '<h1 style="font-family:\'Archivo\',sans-serif;font-weight:900;font-size:clamp(1.8rem,3.5vw,2.6rem);color:#1A1A1A;text-transform:uppercase;margin:0 0 1.5rem;line-height:1.1">' . esc_html( $post->post_title ) . '</h1>';

    // Grid: image + content
    echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;align-items:start">';
    echo '<div>';
    if ( $thumb ) {
        echo $thumb;
    } else {
        echo '<div style="width:100%;height:280px;background:#F3F5F8;border-radius:12px;display:flex;align-items:center;justify-content:center">';
        echo '<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#b3bcc8" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="m3 16 5-5 4 4 3-3 6 6"/><circle cx="8.5" cy="8.5" r="1.5"/></svg>';
        echo '</div>';
    }
    echo '</div>';

    echo '<div>';
    if ( $excerpt ) {
        echo '<p style="font-size:1.05rem;color:#3d4551;margin-bottom:1.5rem;line-height:1.7">' . esc_html( $excerpt ) . '</p>';
    }

    if ( $is_termek ) {
        $kat_id = (int) get_post_meta( $post->ID, '_ohegy_kategoria_id', true );
        if ( $kat_id ) {
            $kat = get_post( $kat_id );
            if ( $kat ) {
                echo '<p style="font-size:.88rem;color:#5B6573;margin-bottom:1.5rem">Kategória: <a href="' . esc_url( get_permalink( $kat_id ) ) . '" style="color:#E2231A;text-decoration:none;font-weight:600">' . esc_html( $kat->post_title ) . '</a></p>';
            }
        }
    }

    // CTA gomb
    $ajanlat_url = get_permalink( 95 ) . '#ajanlat';
    echo '<a href="' . esc_url( $ajanlat_url ) . '" style="display:inline-flex;align-items:center;gap:.5rem;font-family:\'Archivo\',sans-serif;font-weight:700;font-size:.82rem;letter-spacing:.04em;text-transform:uppercase;padding:.9rem 1.8rem;border-radius:4px;background:#E2231A;color:#fff;text-decoration:none;transition:background .2s">Ajánlatkérés</a>';
    echo '</div>';
    echo '</div>'; // grid

    // Ha kategória: listázza a termékeket
    if ( $is_kategoria ) {
        echo '<div style="margin-top:3rem">';
        echo '<h2 style="font-family:\'Archivo\',sans-serif;font-weight:800;font-size:clamp(1.3rem,2.5vw,1.8rem);color:#1A1A1A;text-transform:uppercase;margin-bottom:1.5rem">E kategória termékei</h2>';
        echo do_shortcode( '[ohegy_termekek kategoria="' . $post->ID . '"]' );
        echo '</div>';
    }

    echo '</div></section></div>'; // inner + section + wrapper
}

